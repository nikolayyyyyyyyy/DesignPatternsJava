package lab2;

public enum FileType {
    META,TEXT
}

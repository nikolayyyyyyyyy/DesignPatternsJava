package abstract_factory;

public enum TypesOfSweets {
    CAKE,
    DONUT,
    ECLAIR,
    GINGERBREAD
}

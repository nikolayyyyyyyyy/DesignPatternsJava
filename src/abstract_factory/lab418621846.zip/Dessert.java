package abstract_factory;

public interface Dessert {
    String bake();
}

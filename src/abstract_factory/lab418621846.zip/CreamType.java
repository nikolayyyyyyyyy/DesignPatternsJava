package abstract_factory;

public enum CreamType {
    VANILLA,
    CHOCOLATE
}

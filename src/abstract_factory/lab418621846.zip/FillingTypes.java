package abstract_factory;

public enum FillingTypes {
    CARAMEL,
    NUTELLA,
}

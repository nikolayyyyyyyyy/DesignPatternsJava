package abstract_factory;

public enum GlazeTypes {
    FONDANT,
    MARZIPAN,
    LEMON
}
